document.addEventListener('DOMContentLoaded', () => {
    
    // *** 1. CONFIG: ใช้ค่า Field ID ที่ถูกต้อง 100% จากการวิเคราะห์ล่าสุด ***
    const GOOGLE_FORM_URL = 'https://docs.google.com/forms/d/e/1FAIpQLSfbqhpkecUg_ybrdvx8II20s-f_WCEu4H0BmbvJWgtBaMO5wA/formResponse'; 
    
    const FIELD_ID = {
        name: 'entry.2119879183',      
        nickname: 'entry.1744498140',  
        classRoom: 'entry.1296537747', 
        deskId: 'entry.1171635782',    
        seatId: 'entry.1575781351',     
    };
    // ***************************************************************
    
    const seats = document.querySelectorAll('.seat'); 
    const modal = document.getElementById('booking-modal');
    const closeButton = document.querySelector('.close-button');
    const bookingForm = document.getElementById('booking-form');
    const currentDeskInfo = document.getElementById('current-desk-info');
    let selectedSeat = null; 
    
    // สถานะสำหรับ iframe เพื่อตรวจสอบว่า Form ถูก Submit แล้ว
    window.submitted = false; 

    // ฟังก์ชันจัดการเมื่อการส่งข้อมูลสำเร็จ
    window.handleSuccessfulSubmission = function() {
        if (selectedSeat) {
            const name = document.getElementById('name').value.trim();
            const nickname = document.getElementById('nickname').value.trim();
            const seatId = selectedSeat.getAttribute('data-seat-id');
            const deskId = selectedSeat.closest('.desk').getAttribute('data-desk-id');
            const classRoom = document.getElementById('class-room').value.trim();
            
            // อัปเดตสถานะการจองใน UI (สีแดง)
            selectedSeat.setAttribute('data-status', 'booked');
            selectedSeat.setAttribute('title', `จองโดย: ${name} (${nickname}), ${classRoom}`);
            
            alert(`🎉 การจองที่นั่ง โต๊ะที่ ${deskId} ตำแหน่ง ${seatId} สำเร็จ! ข้อมูลถูกบันทึกใน Google Sheet แล้ว.`);
            closeModal();
        }
    };


    // 1. จัดการการคลิกที่ที่นั่ง (เหมือนเดิม)
    seats.forEach(seat => {
        seat.addEventListener('click', (e) => {
            e.stopPropagation(); 
            
            if (seat.getAttribute('data-status') === 'booked') {
                alert('ที่นั่งนี้ถูกจองแล้ว! กรุณาเลือกที่นั่งอื่น');
                return;
            }

            try {
                selectedSeat = seat;
                const seatId = selectedSeat.getAttribute('data-seat-id'); 
                const deskId = selectedSeat.closest('.desk').getAttribute('data-desk-id'); 

                currentDeskInfo.textContent = `โต๊ะที่ ${deskId} ตำแหน่ง ${seatId}`;
                modal.style.display = 'block';

            } catch (error) {
                console.error("เกิดข้อผิดพลาดในการดึงข้อมูลโต๊ะ/ที่นั่ง:", error);
                alert("ไม่สามารถเปิดฟอร์มจองได้");
            }
        });
    });

    const closeModal = () => {
        modal.style.display = 'none';
        bookingForm.reset(); 
        selectedSeat = null;
    };

    closeButton.addEventListener('click', closeModal);
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeModal();
        }
    });

    // 2. จัดการการส่งฟอร์มจอง (ใช้เทคนิค iframe)
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault(); 

        if (selectedSeat) {
            const name = document.getElementById('name').value.trim();
            const nickname = document.getElementById('nickname').value.trim();
            const classRoom = document.getElementById('class-room').value.trim();
            const seatId = selectedSeat.getAttribute('data-seat-id');
            const deskId = selectedSeat.closest('.desk').getAttribute('data-desk-id');
            
            // 1. สร้างองค์ประกอบ Input Hidden เพื่อส่งข้อมูล DeskID และ SeatID
            // (ต้องล้าง input เก่าก่อนเพื่อป้องกันการส่งข้อมูลซ้ำ)
            document.querySelectorAll('#booking-form input[type="hidden"]').forEach(el => el.remove());

            const hiddenDeskId = document.createElement('input');
            hiddenDeskId.type = 'hidden';
            hiddenDeskId.name = FIELD_ID.deskId;
            hiddenDeskId.value = deskId;
            bookingForm.appendChild(hiddenDeskId);
            
            const hiddenSeatId = document.createElement('input');
            hiddenSeatId.type = 'hidden';
            hiddenSeatId.name = FIELD_ID.seatId;
            hiddenSeatId.value = seatId;
            bookingForm.appendChild(hiddenSeatId);

            // 2. ตั้งค่า Form เพื่อส่งข้อมูลไปที่ Google Form และให้ iframe รับ Response
            bookingForm.action = GOOGLE_FORM_URL;
            bookingForm.method = 'POST';
            bookingForm.target = 'hidden_iframe';
            
            // 3. ตั้งค่าสถานะว่ากำลังจะส่ง และสั่งให้ Form ส่งข้อมูล
            window.submitted = true;
            bookingForm.submit(); 
            
            // ไม่ต้องทำอะไรต่อในนี้ เพราะ handleSuccessfulSubmission() จะถูกเรียกเมื่อ iframe โหลดเสร็จ
        }
    });
});
